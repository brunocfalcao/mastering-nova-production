<?php

namespace App\Listeners\Paddle;

use App\PaddleLog;
use App\User;
use Illuminate\Http\Request;
use ProtoneMedia\LaravelPaddle\Events\PaymentSucceeded as EventPaymentSucceeded;

class PaymentSucceeded
{
    public $request;

    /**
     * Create the event listener.
     *
     * @param  Request  $request
     * @return void
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * Handle the event.
     *
     * @param  Login  $event
     * @return void
     */
    public function handle(EventPaymentSucceeded $event)
    {
        $checkout = $event->all();

        // Testing purposes only. delete both user and order if they exist.
        if (app()->environment() != 'production') {
            User::where('email', $checkout['email'])->forceDelete();
            PaddleLog::where('email', $checkout['email'])->delete();
        }

        $paddleLog = PaddleLog::storeCheckout($checkout);

        activity()
            ->performedOn($paddleLog)
            ->withProperties(['checkout_data' => $checkout])
            ->log('Checkout data successfully created');

        // Create user from purchase.
        $user = User::createFromPurchase($paddleLog);

        activity()
            ->performedOn($user)
            ->withProperties(
                ['checkout_data' => $checkout,
                 'user_data' => $user->get(), ]
            )
            ->log('Paid user successfully created - '.$user->name.', '.$user->email);
    }
}
