<?php

namespace App\Mail;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ResetYourPassword extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $link;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(User $user, string $token)
    {
        $this->link = url(route('password.reset', [
                              'token' => $token,
                              'email' => $user->email,
                        ], false));
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from(
            'bruno@masteringnova.com',
            'Bruno from Mastering Nova Course'
        )->view('emails.auth.reset-email');
    }
}
