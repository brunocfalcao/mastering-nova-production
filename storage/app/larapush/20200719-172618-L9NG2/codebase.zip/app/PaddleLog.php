<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaddleLog extends Model
{
    protected $fillable = [
        'alert_id',
        'alert_name',
        'checkout_id',
        'country',
        'currency',
        'customer_name',
        'email',
        'event_time',
        'order_id',
        'payment_method',
        'receipt_url',
        'sale_gross',
        'gross_refund',
        'refund_reason',
        'passthrough',
        'payload',
    ];

    protected $table = 'paddle_log';

    protected $casts = [
        'event_time' => 'datetime',
        'passthrough' => 'array',
        'payload' => 'array',
    ];

    public static function storeCheckout($checkout)
    {
        return PaddleLog::create(array_merge($checkout, ['payload' => $checkout]));
    }
}
