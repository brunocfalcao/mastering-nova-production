<?php

namespace App\Services;

use ProtoneMedia\LaravelPaddle\Paddle;

class PayLink
{
    protected $payLink;

    public static function make()
    {
        return new self();
    }

    protected function inSession()
    {
        return filled(session('website-paylink'));
    }

    protected function fromSession()
    {
        return session('website-paylink');
    }

    protected function toSession()
    {
        session(['website-paylink' => $this]);
    }

    public function link($price)
    {
        if ($this->inSession()) {
            $this->payLink = $this->fromSession()->payLink;

            return $this->payLink;
        }

        $this->payLink = Paddle::product()
            ->generatePayLink()
            ->productId(env('PADDLE_PRODUCT_ID'))
            ->returnUrl(secure_url('/paddle/thanks/{checkout_hash}'))
            ->quantityVariable(0)
            ->quantity(1)
            ->passthrough([
                'price' => (array) $price,
            ])
            ->prices(["USD:{$price->amount->checkout}"])
            ->send();

        $this->toSession();

        return $this->payLink;
    }
}
