<?php

namespace App\Features\Videos\Controllers;

use App\Chapter;
use App\Http\Controllers\Controller;
use App\Video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class VideosController extends Controller
{
    public function __construct()
    {
        // Add your middleware, if needed.
    }

    public function index()
    {
        // Get first playable video.
        if (Auth::guest()) {
            $lastSeenVideo = Video::free()->first();
        } else {
            // Get last video seen, or if not, then first video.
            $lastSeenVideo = Video::where('id', DB::table('videos_completed')
                 ->select('video_id')
                 ->where('user_id', Auth::id())
                 ->orderBy('id', 'desc')
                 ->value('video_id'))
                 ->firstOr(function () {
                     return Video::where('id', 1)->first();
                 });
            /*
            if (is_null($lastSeenVideo)) {
                $lastSeenVideo = Video::where('id', 1)->first();
            }
            */
        }

        return flame(['chapters' => Chapter::all(), 'playable' => $lastSeenVideo]);
    }

    public function play(Request $request, Video $video)
    {
        return flame(['chapters' => Chapter::all(), 'playable' => $video]);
    }

    public function completed(Request $request, Video $video)
    {
        Auth::user()->videosCompleted()->attach($video);

        return back();
    }
}
