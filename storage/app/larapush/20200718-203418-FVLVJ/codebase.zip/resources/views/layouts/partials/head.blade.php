<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSRF Token -->
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $title ?? 'Mastering Nova - Laravel Nova Tutorial' }}</title>
<meta name="description" content= "Laravel Nova Tutorial - Learn Laravel Nova from scratch, how to create advanced UI components, multi-tenancy, making Tools, and much more" />
<meta name="robots" content= "index, follow">

<!-- SEO metadata -->
<meta property="og:title" content="Mastering Laravel Nova - A Laravel Nova tutorial"/>
<meta property="og:description" content="Laravel Nova Tutorial - Learn Laravel Nova from scratch, how to create advanced UI components, multi-tenancy, making Tools, and much more"/>
<meta property="og:type" content="website"/>
<meta property="og:image" content="https://www.masteringnova.com/images/seo-image.jpg"/>
<meta property="og:url" content="https://www.masteringnova.com"/>
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:site" content="@brunocfalcao" />
<meta property="twitter:title" content="Mastering Nova - A Laravel Nova tutorial" />
<meta property="twitter:description" content="Laravel Nova Tutorial - Learn Laravel Nova from scratch, how to create advanced UI components, multi-tenancy, making Tools, and much more" />
<meta property="twitter:image" content="https://www.masteringnova.com/images/seo-image.jpg" />

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Nunito:200,400,500,600,700,800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Fira+Code&display=swap" rel="stylesheet">

<!-- Tailwind + Website styles -->
<link href="{{ mix('css/app.css') }}" rel="stylesheet">

@env('production')
<!-- Hotjar Tracking Code for https://www.masteringnova.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1809344,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>

<!-- Matomo -->
<script type="text/javascript">
  var _paq = window._paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="https://matomo.waygou.com/";
    _paq.push(['setTrackerUrl', u+'matomo.php']);
    _paq.push(['setSiteId', '1']);
    _paq.push(['enableHeartBeatTimer', 15]);
    @routename('welcome.subscribed')
    _paq.push(['trackGoal', 1]);
    @endroutename
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="https://matomo.waygou.com/matomo.php?idsite=1&amp;rec=1" style="border:0;" alt="" /></p></noscript>
<!-- End Matomo Code -->
@endenv


<!-- Extra styles / meta data -->
@stack('head')