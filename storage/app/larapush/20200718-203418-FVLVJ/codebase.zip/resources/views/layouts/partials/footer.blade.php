<!-- Footer -->
<footer class="w-full bg-indigo-900 py-8">
    <div class="text-center font-bold text-xl">&#169; Mastering Nova - All rights reserved</div>
    <div class="text-center"><a href="#" target="_blank" class="link-dark">Contact</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#" target="_blank" class="link-dark">Privacy and Cookie Policy</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#" target="_blank" class="link-dark">Terms of Usage</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#" target="_blank" class="link-dark">Twitter</a></div>
</footer>
