<?php

namespace App\Services;

use App\Country;
use App\Utils\Price;
use App\Website;
use Illuminate\Support\Facades\Request;
use ProtoneMedia\LaravelPaddle\Paddle;

class WebsiteCheckout
{
    protected $price;

    public function __construct()
    {
        $this->getPrice();
    }

    public static function make()
    {
        $checkout = new WebsiteCheckout();

        return $checkout;
    }

    protected function inSession()
    {
        return filled(session('website-checkout')) && env('PADDLE_CHECKOUT_SESSION') == 1;
    }

    protected function fromSession()
    {
        return session('website-checkout');
    }

    protected function toSession()
    {
        session(['website-checkout' => $this]);
    }

    /**
     * Makes a Paddle api call.
     *
     * @param  string $type
     *
     * @return mixed
     */
    protected function callPaddleApi(string $type)
    {
        try {
            switch ($type) {
                case 'prices':
                    return (object) (Paddle::checkout()
                ->getPrices([
                    'product_ids' => env('PADDLE_PRODUCT_ID'),
                    'customer_ip' => request()->ip2(), ])
                ->send());

                break;
            }
        } catch (\Exception $e) {
            // Log error as application log.
            activity()
                ->withProperties(
                    ['ip' => request()->ip2()]
                )
                ->log('ERROR:: Paddle API error - '.$e->getMessage().' in '.$e->getFile().' at line '.$e->getLine());

            return;
        }
    }

    /**
     * Resolves a Paddle api result into a price customized object.
     *
     * @param  mixed $price
     *
     * @return \StdClass
     */
    protected function resolvePrice($payload)
    {
        $result = [];
        data_set($result, 'request.ip', request()->ip2());

        data_set($result, 'request.country.code', $payload->customer_country);
        data_set($result, 'request.country.name', Country::firstWhere('code', $payload->customer_country)->name);
        data_set($result, 'currency.name', $payload->products[0]['currency']);
        data_set($result, 'amount.original', $payload->products[0]['price']['net']);

        data_set($result, 'currency.name', 'USD');
        data_set($result, 'currency.symbol', '$');

        return json_decode(json_encode($result));
    }

    /**
     * Obtains the original product price from Paddle (or a default).
     * Converts price using PPP.
     * Updates $this->price with all the information.
     *
     * @return void
     */
    protected function getProductPrice()
    {
        /**
         * Obtain a price object given the api product price result
         * or a default value from the website.
         */
        $result = $this->callPaddleApi('prices');
        $this->price = $this->resolvePrice($result);

        /**
         * Compute the PPP in case a country exists.
         * Get country.
         * Get ppp_index (default is 1).
         * Convert price via ppp_index.
         */
        $country = Country::where('code', $this->price->request->country->code)
                          ->firstOr(function () {
                              $country = new Country();
                              $country->ppp_index = 1;

                              return $country;
                          });

        if (! $this->usePPP()) {
            $country->ppp_index = 1;
        }

        $this->price->amount->checkout = (int) ceil($country->ppp_index * $this->price->amount->original);

        $this->price->discount = new \StdClass();
        $this->price->discount->percentage = (int) round(100 - ceil($country->ppp_index * 100));
        $this->price->discount->amount = (int) ($this->price->amount->original -
                                         $this->price->amount->checkout);
        $this->session = false;

        return $this->price;
    }

    protected function usePPP()
    {
        return Request::input('ppp');
    }

    protected function getPrice()
    {
        if ($this->inSession()) {
            // Use session pricing.
            $this->price = $this->fromSession()->price;
            $this->session = true;

            return $this->price;
        } else {
            // Let's go to paddle and get the current price information.
            $this->getProductPrice();
        }

        $this->toSession();
    }

    public function payLink()
    {
        $link = PayLink::make()->link($this->price);

        return $link['url'];
    }

    public function price()
    {
        return $this->price;
    }
}
