<?php

namespace App\Providers;

use App\Chapter;
use App\Link;
use App\Observers\ChapterObserver;
use App\Observers\LinkObserver;
use App\Observers\UserObserver;
use App\Observers\VideoObserver;
use App\Services\WebsiteCheckout;
use App\User;
use App\Video;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class MasteringNovaProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->registerContainers();
        $this->registerMacros();
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerListeners();
        $this->updateSchema();
        $this->registerBladeDirectives();
        $this->registerObservers();
        $this->registerGates();
    }

    protected function registerGates()
    {

        /*
         * If the video is not active, return false.
         * If the user is logged in, return true.
         * If the video is free, return true.
         */
        Gate::define('play-video', function (?User $user, Video $video) {
            if ($video->is_active == false) {
                return false;
            }

            if (Auth::id()) {
                return true;
            }

            return ! $video->is_premium;
        });
    }

    protected function registerMacros()
    {
        // Include all files from the Macros folder.
        Collection::make(glob(app_path('Macros').'/*.php'))
                  ->mapWithKeys(function ($path) {
                      return [$path => pathinfo($path, PATHINFO_FILENAME)];
                  })
                  ->each(function ($macro, $path) {
                      require_once $path;
                  });
    }

    protected function registerContainers()
    {
        $this->app->singleton('website-checkout', function () {
            return new WebsiteCheckout();
        });
    }

    protected function registerListeners()
    {
        Event::listen('auth.login', function ($user) {
            $user->last_login_at = now();
            $user->save();
        });
    }

    protected function registerBladeDirectives()
    {
        Blade::if('env', function ($environment) {
            return app()->environment($environment);
        });

        Blade::if('routename', function ($name) {
            return Route::currentRouteName() == $name;
        });

        // Register checkout return url.
        Route::any(
            'paddle/thanks/{checkout}',
            '\App\Features\Purchased\Controllers\PurchasedController@thanks'
        )
             ->name('purchased.thanks');
    }

    protected function updateSchema()
    {
        Schema::defaultStringLength(191);
    }

    protected function registerObservers()
    {
        User::observe(UserObserver::class);
        Video::observe(VideoObserver::class);
        Chapter::observe(ChapterObserver::class);
        Link::observe(LinkObserver::class);
    }
}
