<?php

use App\Facades\WebsiteCheckout;
use App\PaddleLog;
use App\User;
use Illuminate\Support\Facades\Route;
use ProtoneMedia\LaravelPaddle\Events\PaymentSucceeded;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get(
    'videos/{video}',
    '\App\Features\Videos\Controllers\VideosController@play'
)->name('videos.play')
 ->middleware('can-interact');

if (env('LAUNCHED') == 1) {
    Auth::routes(['register' => false, 'confirm' => false, 'verify' => false]);
}

Route::get(
    'videos',
    '\App\Features\Videos\Controllers\VideosController@index'
)->name('videos');

Route::get('/ppp', function () {
    session()->forget('website-checkout');
    session()->forget('website-paylink');

    return redirect(route('welcome', ['ppp' => 1]));
})->name('welcome.ppp');

Route::post(
    'videos/completed/{video}',
    '\App\Features\Videos\Controllers\VideosController@completed'
)->name('videos.completed')
 ->middleware('can-interact');

/*
 * Extremely important to have a throttle for the paylink since
 * hackers might try to charge cards in a bulk way.
 * This way it will block the user from trying again.
 * 3 requests per minute should be enough.
 */
Route::get('/paylink', function () {
    return redirect(WebsiteCheckout::make()->payLink());
})->name('checkout.paylink')
  ->middleware('throttle:3,1');

Route::get('/webhook/download', function () {
    return response('Purchase successful. Thank you for buying my Course. Hope you enjoy it as much as I did making it for you. Let me know if any issues!', 200);
});

Route::get(
    '/',
    '\App\Features\Welcome\Controllers\WelcomeController@index'
)->name('welcome');

Route::post(
    '/',
    '\App\Features\Welcome\Controllers\WelcomeController@subscribe'
)->name('welcome.subscribed');

if (app()->environment() != 'production') {
    Route::get('/test-checkout/{checkout}', function (string $checkout) {
        $event = PaddleLog::firstWhere('checkout_id', $checkout);

        //$event->passthrough = stripcslashes($event->passthrough);
        //$event->payload = stripcslashes($event->payload);
        //$event->save();

        if (blank($event)) {
            return response("Checkout it unknown ({$checkout}).");
        }

        // Delete user from the $event.
        User::where('email', $event->email)->forceDelete();
        event(new PaymentSucceeded($event->toArray(), request()));

        return response('Checkout test process client email - '.$event->email);
    });
}

Route::redirect('/home', '/videos');
