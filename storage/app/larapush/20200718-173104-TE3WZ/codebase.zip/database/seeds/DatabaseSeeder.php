<?php

use App\Chapter;
use App\Country;
use App\Link;
use App\User;
use App\Video;
use App\Website;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // Delete all folders/files in the storage public directory.
        collect(Storage::allDirectories('public'))->each(function ($directory) {
            Storage::deleteDirectory($directory);
        });

        $lines = file(base_path('database/seeds/countries.csv'), FILE_IGNORE_NEW_LINES);

        foreach ($lines as $line) {
            $country = explode(',', $line);

            Country::create([
                'code' => $country[1],
                'name' => str_replace(['"', '/'], ['', ''], $country[2]),

                // No ppp index ? Then should be 1.
                'ppp_index' => $country[3] == 'NULL' ? 1 : $country[3], ]);
        }

        User::create([
            'name' => 'Bruno Falcao',
            'email' => 'bruno@masteringnova.com',
            'password' => bcrypt('password'),
        ]);

        // Create test users.
        //factory(User::class, rand(50, 100))->create();

        // Create random chapters and videos attached to them.
        factory(Chapter::class, 5)->create()->each(function ($chapter) {
            factory(Video::class, rand(3, 5))->create()->each(function ($video) use ($chapter) {
                $video->chapter()->associate($chapter)->save();
            });
        });

        // Create random links per video, and attach them.
        Video::all()->each(function ($video) {
            factory(Link::class, rand(3, 5))->create()->each(function ($link) use ($video) {
                $link->video()->associate($video)->save();
            });
        });

        // For each user, make the watch random videos.
        User::all()->each(function ($user) {
            $user->videosCompleted()->attach(
                Video::orderbyRaw('rand()')->take(rand(1, 10))->pluck('id')
            );
        });

        // Create website.
        factory(Website::class, 1)->create();
    }
}
