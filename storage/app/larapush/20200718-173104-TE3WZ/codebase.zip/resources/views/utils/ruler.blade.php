@env('local')
<div class="absolute inset-0 z-200 mx-auto w-2 opacity-25 h-screen bg-red-500"></div>
@endenv